package mdc.appmanualdocalouro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ContatoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato);
    }
}