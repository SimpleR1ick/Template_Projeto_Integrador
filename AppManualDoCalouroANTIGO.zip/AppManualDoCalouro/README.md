# App Manual do Calouro
## Repositório para salvar a versão mobile do Projeto Integrador.

### Regras
**1.** Quando for alterar algo que alterará o projeto em outras partes, crie uma branch nova. <br>
**2.** Trabalhe na branch develop. Apenas mande para a branch main quando o projeto estiver finalizado e pronto para ser enviado ao professor.
